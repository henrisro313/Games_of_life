/** Kagome tiling geometry and the fixed reflection used by the evolutionary search. */
public class Kagome extends AbstractLattice {
    public Kagome() {
        super(8, 14, 16, 0,
                new int[][] {{-4, 4, 8, 4, -4, -8}, {-4, 4, 0}, {4, 8, 12}},
                new int[][] {{7, 7, 0, -7, -7, 0}, {7, 7, 14}, {7, 0, 7}});
    }

    @Override
    public boolean isInterestingOscillationPeriod(int period) {
        return period != 2 && period != 3 && period != 4 && period != 5
                && period != 6 && period != 7 && period != 8 && period != 9
                && period != 12 && period != 21 && period != 32 && period != 35;
    }

    /** Reflects across the fixed line through (-3, -3, A) and (-3, 7, A). */
    public LatticeCell reflectExact(LatticeCell cell) {
        final int[] xOffsets = {-6, -7, -7};
        final int[] yOffsets = {3, 3, 4};
        int sub = cell.sub;
        int reflectedX = -cell.x + xOffsets[sub];
        int reflectedY = cell.x + cell.y + yOffsets[sub];
        int reflectedSub = sub == 0 ? 0 : (sub == 1 ? 2 : 1); // A stays A; B and C swap.
        return new LatticeCell(reflectedX, reflectedY, reflectedSub);
    }
}
