#!/bin/sh
# Compile all application sources and rebuild the executable JAR. Requires JDK 11+.
set -eu
cd "$(dirname "$0")"
mkdir -p build/classes
javac --release 11 -Xlint:all -Werror -d build/classes ./*.java
jar --create --file GoL_evolutionary.jar --main-class GenericLifeSymmetricEvolution -C build/classes .
printf '%s\n' 'Built GoL_evolutionary.jar'
