import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;

/**
 * Searches for Kagome structures that recover after a collision and produce a target pattern.
 * Each attempt mutates the original static structure, simulates the collision, and scores it.
 * Run with {@code java GenericLifeSymmetricEvolution}; configuration is defined below.
 */
public class GenericLifeSymmetricEvolution {
    private static final int RADIUS = 4; // Number of neighbour steps per mutation.
    private static final int MAXGEN = 200; // Includes the initial generation.
    private static final int LOG_INTERVAL = 2000;
    private static final int MUTATIONS_PER_TRY = 6;
    private static final String LOG_FILE = "fitness_log.txt";
    private static final String CANDIDATE_LOG_FILE = "candidate_log.txt";
    private static final double MIN_FITNESS_IMPROVEMENT = 0.01;
    private static final double SUCCESS_FITNESS = 0.9999999;

    public static final boolean ENFORCE_SYMMETRY = true;

    private static final String STATIC_PATTERN =
            "-6 -4 B -1 -7 C -1 -7 A -5 -5 C -5 -5 B -5 -5 A -4 -6 C -4 -6 B " +
            "-1 -6 B -3 -7 C 0 -7 C -4 -5 B -3 -6 C -3 -6 B 0 -6 B -2 -7 C " +
            "1 -7 A -7 -3 C -7 -3 B -7 -3 A -2 -6 B -6 -4 C";

    private static final String INCOMING_PATTERN =
            "-4 11 C -2 12 A -3 8 B -1 9 C -4 4 A -2 5 A -2 5 B -1 3 C " +
            "-6 6 B -5 4 A -5 4 C -3 5 B -2 8 B 0 9 A -2 3 A -2 3 B " +
            "-1 10 B -5 11 C -4 13 A -3 11 B -1 7 A -4 6 A -5 12 C -2 10 B " +
            "-1 8 A -5 9 A -5 9 C -1 11 A -2 11 B -2 11 C -4 5 C -6 12 A " +
            "-6 12 B -5 6 C -6 12 C -5 10 A -4 8 C -5 13 A -1 2 A -5 13 B";

    private static final String DESIRED_PATTERN =
            "-5 17 A -5 17 B -5 17 C -2 12 C -5 7 C -4 14 A -1 9 B -1 9 C " +
            "-2 15 B -2 15 C -4 17 A -5 14 A 6 -6 B -5 14 B -5 14 C -13 3 A " +
            "-13 3 C 0 9 A -5 8 C -2 16 A -2 16 B -14 3 C -5 11 B -5 11 C " +
            "-2 6 B -5 15 C -2 9 C -1 7 A -2 7 A -2 7 B 8 -7 A -2 10 A " +
            "-2 10 B -6 11 C -5 9 A -2 13 A -2 13 B -1 15 A -5 16 C -6 12 A " +
            "-6 12 B -4 8 A -2 14 B -1 12 A -1 12 C 7 -7 C -6 15 B 7 -7 B " +
            "7 -7 A -14 4 A -14 4 B -4 11 A";

    // These cells enable the symmetry branch. The actual axis is fixed in Kagome.reflectExact.
    private static AbstractLattice.LatticeCell symCell1;
    private static AbstractLattice.LatticeCell symCell2;

    /** Anchor storage; the search selects mutation anchors from the base structure, not this list. */
    public static List<AbstractLattice.LatticeCell> REGION_ANCHORS = new ArrayList<>();

    private static final Random RNG = new Random();

    public static void main(String[] args) throws IOException {
        Kagome kagome = new Kagome();
        Set<AbstractLattice.LatticeCell> staticStruct = kagome.parseCells(STATIC_PATTERN.split(" "));
        Set<AbstractLattice.LatticeCell> incomingGlider = kagome.parseCells(INCOMING_PATTERN.split(" "));
        Set<AbstractLattice.LatticeCell> desiredOut = kagome.parseCells(DESIRED_PATTERN.split(" "));

        symCell1 = kagome.parseCells("-3 -3 A".split(" ")).iterator().next();
        symCell2 = kagome.parseCells("-3 7 A".split(" ")).iterator().next();
        REGION_ANCHORS.addAll(kagome.parseCells("2 4 C".split(" ")));
        REGION_ANCHORS.addAll(kagome.parseCells("-9 10 B".split(" ")));

        System.out.println("staticStruct element type: " + staticStruct.iterator().next().getClass());
        System.out.println("incomingGlider element type: " + incomingGlider.iterator().next().getClass());
        System.out.println("desiredOut element type: " + desiredOut.iterator().next().getClass());
        runEvolution(kagome, staticStruct, incomingGlider, desiredOut);
    }

    private static void runEvolution(
            Kagome kagome,
            Set<AbstractLattice.LatticeCell> baseStatic,
            Set<AbstractLattice.LatticeCell> incomingGlider,
            Set<AbstractLattice.LatticeCell> desiredOut) throws IOException {
        int attempt = 0;
        double bestFitness = -Double.MAX_VALUE;
        Set<AbstractLattice.LatticeCell> bestStatic = new HashSet<>(baseStatic);

        try (BufferedWriter log = new BufferedWriter(new FileWriter(LOG_FILE, true))) {
            while (true) {
                attempt++;
                // Start each independent trial from the base structure.
                Set<AbstractLattice.LatticeCell> candidateStatic =
                        mutateStatic(kagome, baseStatic, MUTATIONS_PER_TRY);
                Set<AbstractLattice.LatticeCell> initial = new HashSet<>(candidateStatic);
                initial.addAll(incomingGlider);

                List<Set<AbstractLattice.LatticeCell>> generations = evolve(kagome, initial, MAXGEN);
                FitnessResult result = evaluateFitness(candidateStatic, generations, desiredOut);

                if (attempt % LOG_INTERVAL == 0) {
                    log.write(String.format(
                            "Attempt %d: fitness=%.4f staticScore=%.4f outputScore=%.4f%n",
                            attempt, result.fitness, result.staticScore, result.outputScore));
                    log.flush();
                    System.out.println("Attempt " + attempt + ", best fitness so far: " + bestFitness);
                }

                if (result.fitness > bestFitness + MIN_FITNESS_IMPROVEMENT) {
                    bestFitness = result.fitness;
                    bestStatic = new HashSet<>(candidateStatic);
                    saveCandidate(attempt, result, kagome, candidateStatic, generations);
                }

                if (result.fitness >= SUCCESS_FITNESS) {
                    System.out.println("SUCCESS at attempt " + attempt);
                    log.write("SUCCESS at attempt " + attempt + "\n");
                    log.write("Winning static: " + kagome.format(bestStatic) + "\n");
                    log.flush();

                    String filename = "reflector_success_" + System.nanoTime() + ".gif";
                    try {
                        createAnimatedGif(filename, kagome, generations);
                        log.write("Saved GIF: " + filename + "\n");
                    } catch (IOException e) {
                        log.write("Failed to save GIF: " + e.getMessage() + "\n");
                    }
                    break;
                }
            }
        }
    }

    private static void saveCandidate(
            int attempt,
            FitnessResult result,
            Kagome kagome,
            Set<AbstractLattice.LatticeCell> candidate,
            List<Set<AbstractLattice.LatticeCell>> generations) throws IOException {
        try (BufferedWriter log = new BufferedWriter(new FileWriter(CANDIDATE_LOG_FILE, true))) {
            log.write(String.format(
                    "Attempt %d fitness=%.4f staticScore=%.4f outputScore=%.4f%n",
                    attempt, result.fitness, result.staticScore, result.outputScore));
            log.write("Static structure: " + kagome.format(candidate) + "\n\n");
        }

        String filename = "candidate_" + attempt + ".gif";
        try {
            createAnimatedGif(filename, kagome, generations);
            System.out.println("Saved candidate GIF: " + filename);
        } catch (IOException e) {
            System.err.println("Failed to save candidate GIF: " + e.getMessage());
        }
    }

    /** Toggles each randomly selected cell and, when enabled, its exact reflection. */
    private static Set<AbstractLattice.LatticeCell> mutateStatic(
            Kagome kagome, Set<AbstractLattice.LatticeCell> base, int flips) {
        List<AbstractLattice.LatticeCell> baseList = new ArrayList<>(base);
        Set<AbstractLattice.LatticeCell> mutated = new HashSet<>(base);

        for (int i = 0; i < flips; i++) {
            AbstractLattice.LatticeCell anchor = baseList.get(RNG.nextInt(baseList.size()));
            AbstractLattice.LatticeCell cell = randomNearbyCell(kagome, anchor, RADIUS);
            if (ENFORCE_SYMMETRY && symCell1 != null && symCell2 != null) {
                AbstractLattice.LatticeCell mirror = kagome.reflectExact(cell);
                toggle(mutated, cell);
                if (!cell.equals(mirror)) {
                    toggle(mutated, mirror);
                }
            } else {
                toggle(mutated, cell);
            }
        }
        return mutated;
    }

    private static void toggle(Set<AbstractLattice.LatticeCell> cells, AbstractLattice.LatticeCell cell) {
        if (!cells.add(cell)) {
            cells.remove(cell);
        }
    }

    /** A fixed-length random walk; the endpoint can be closer than radius to the origin. */
    private static AbstractLattice.LatticeCell randomNearbyCell(
            Kagome kagome, AbstractLattice.LatticeCell origin, int radius) {
        AbstractLattice.LatticeCell current = origin;
        for (int i = 0; i < radius; i++) {
            Collection<AbstractLattice.LatticeCell> neighbours = kagome.neighbours(current);
            if (neighbours.isEmpty()) {
                break;
            }
            int index = RNG.nextInt(neighbours.size());
            Iterator<AbstractLattice.LatticeCell> iterator = neighbours.iterator();
            for (int j = 0; j < index; j++) {
                iterator.next();
            }
            current = iterator.next();
        }
        return current;
    }

    /** Stops on extinction or before adding a repeated generation. */
    private static List<Set<AbstractLattice.LatticeCell>> evolve(
            Kagome kagome, Set<AbstractLattice.LatticeCell> initial, int numGens) {
        Map<Set<AbstractLattice.LatticeCell>, Integer> firstSeen = new HashMap<>();
        List<Set<AbstractLattice.LatticeCell>> generations = new ArrayList<>();
        Set<AbstractLattice.LatticeCell> alive = new HashSet<>(initial);
        generations.add(alive);
        firstSeen.put(new HashSet<>(alive), 0);

        for (int generation = 1; generation < numGens; generation++) {
            if (alive.isEmpty()) {
                break;
            }
            Set<AbstractLattice.LatticeCell> next = GenericLife.nextGeneration(kagome, alive);
            if (firstSeen.containsKey(next)) {
                break;
            }
            generations.add(next);
            firstSeen.put(new HashSet<>(next), generation);
            alive = next;
        }
        return generations;
    }

    /**
     * Combines peak static recovery in the last ten generations with peak target coverage
     * over the whole trial. Penalizes excess population in the final generation.
     */
    private static FitnessResult evaluateFitness(
            Set<AbstractLattice.LatticeCell> candidateStatic,
            List<Set<AbstractLattice.LatticeCell>> generations,
            Set<AbstractLattice.LatticeCell> desiredOut) {
        int count = generations.size();
        int window = Math.min(10, count);
        double staticScore = 0.0;
        for (int i = count - window; i < count; i++) {
            staticScore = Math.max(staticScore, coverage(candidateStatic, generations.get(i)));
        }

        double outputScore = 0.0;
        for (Set<AbstractLattice.LatticeCell> generation : generations) {
            outputScore = Math.max(outputScore, coverage(desiredOut, generation));
        }

        Set<AbstractLattice.LatticeCell> finalGeneration = generations.get(count - 1);
        int extras = Math.max(0, finalGeneration.size() - (candidateStatic.size() + desiredOut.size()));
        double extraPenalty = Math.min(1.0, extras / 10.0);
        double fitness = (0.5 * staticScore + 0.5 * outputScore) * (1.0 - extraPenalty);
        return new FitnessResult(fitness, staticScore, outputScore);
    }

    private static double coverage(
            Set<AbstractLattice.LatticeCell> target, Set<AbstractLattice.LatticeCell> generation) {
        int present = 0;
        for (AbstractLattice.LatticeCell cell : target) {
            if (generation.contains(cell)) {
                present++;
            }
        }
        return target.isEmpty() ? 1.0 : (double) present / target.size();
    }

    private static class FitnessResult {
        final double fitness;
        final double staticScore;
        final double outputScore;

        FitnessResult(double fitness, double staticScore, double outputScore) {
            this.fitness = fitness;
            this.staticScore = staticScore;
            this.outputScore = outputScore;
        }
    }

    private static void createAnimatedGif(
            String filename, Kagome kagome,
            List<Set<AbstractLattice.LatticeCell>> generations) throws IOException {
        GifAnimation.write(filename, kagome, generations, 15, 30, 1000, true);
    }
}
