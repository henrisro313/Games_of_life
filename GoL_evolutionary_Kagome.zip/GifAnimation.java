import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import javax.imageio.IIOImage;
import javax.imageio.ImageIO;
import javax.imageio.ImageTypeSpecifier;
import javax.imageio.ImageWriter;
import javax.imageio.metadata.IIOMetadata;
import javax.imageio.metadata.IIOMetadataNode;
import javax.imageio.stream.ImageOutputStream;
import org.w3c.dom.Node;

/** Shared GIF encoding with configurable margins, frame timing, and loop-frame policy. */
final class GifAnimation {
    private GifAnimation() {}

    /** Frame delays are in hundredths of a second. Zero loop count means repeat indefinitely. */
    static <Cell> void write(
            String filename, Tiling<Cell> tiling, List<Set<Cell>> generations,
            int margin, int frameDelay, int lastFrameDelay, boolean skipRepeatedInitial)
            throws IOException {
        ImageWriter writer = ImageIO.getImageWritersByFormatName("gif").next();
        try (OutputStream output = new FileOutputStream(filename);
                ImageOutputStream imageOutput = ImageIO.createImageOutputStream(output)) {
            writer.setOutput(imageOutput);
            writer.prepareWriteSequence(null);
            Rectangle bounds = boundingBox(tiling, generations, margin);
            Set<Cell> initial = generations.get(0);
            for (int i = 0; i < generations.size(); i++) {
                Set<Cell> alive = generations.get(i);
                if (skipRepeatedInitial && i > 0 && alive.equals(initial)) {
                    break;
                }
                BufferedImage image = GenericLife.render(tiling, bounds, alive);
                int delay = i == generations.size() - 1 ? lastFrameDelay : frameDelay;
                writeFrame(writer, image, i == 0, delay);
            }
            writer.endWriteSequence();
        } finally {
            writer.dispose();
        }
    }

    private static <Cell> Rectangle boundingBox(
            Tiling<Cell> tiling, Collection<? extends Collection<Cell>> generations, int margin) {
        Rectangle bounds = new Rectangle(-1, -1);
        Set<Cell> allCells = new HashSet<>();
        for (Collection<Cell> generation : generations) {
            allCells.addAll(generation);
        }
        for (Cell cell : allCells) {
            int[][] vertices = tiling.bounds(cell);
            int[] xs = vertices[0];
            int[] ys = vertices[1];
            for (int i = 0; i < xs.length; i++) {
                bounds.add(xs[i], ys[i]);
            }
        }
        bounds.grow(margin, margin);
        return bounds;
    }

    private static void writeFrame(
            ImageWriter writer, BufferedImage image, boolean firstFrame, int delay)
            throws IOException {
        IIOMetadata metadata = writer.getDefaultImageMetadata(new ImageTypeSpecifier(image), null);
        String format = metadata.getNativeMetadataFormatName();
        Node root = metadata.getAsTree(format);
        IIOMetadataNode control = findOrCreateNode(root, "GraphicControlExtension");
        control.setAttribute("delayTime", Integer.toString(delay));
        control.setAttribute("disposalMethod", "doNotDispose");

        if (firstFrame) {
            IIOMetadataNode extensions = findOrCreateNode(root, "ApplicationExtensions");
            IIOMetadataNode application = findOrCreateNode(extensions, "ApplicationExtension");
            application.setAttribute("applicationID", "NETSCAPE");
            application.setAttribute("authenticationCode", "2.0");
            application.setUserObject(new byte[] {1, 0, 0});
        }

        metadata.setFromTree(format, root);
        writer.writeToSequence(new IIOImage(image, null, metadata), null);
    }

    private static IIOMetadataNode findOrCreateNode(Node parent, String name) {
        for (Node child = parent.getFirstChild(); child != null; child = child.getNextSibling()) {
            if (child.getNodeName().equals(name)) {
                return (IIOMetadataNode) child;
            }
        }
        IIOMetadataNode node = new IIOMetadataNode(name);
        parent.appendChild(node);
        return node;
    }
}
