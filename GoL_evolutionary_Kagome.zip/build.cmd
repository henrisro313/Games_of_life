@echo off
setlocal
cd /d "%~dp0"
if not exist build\classes mkdir build\classes
javac --release 11 -Xlint:all -Werror -d build\classes *.java
if errorlevel 1 exit /b 1
jar --create --file GoL_evolutionary.jar --main-class GenericLifeSymmetricEvolution -C build\classes .
if errorlevel 1 exit /b 1
echo Built GoL_evolutionary.jar
