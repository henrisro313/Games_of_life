# Game of Life on a Kagome lattice
# Created by Henrik Schou Guttesen, 13/09/2026
# Prepared using ChatGPT-6 Astra Medium

A Java application for exploring Life-like cellular automata on a Kagome lattice.
It includes an evolutionary search for collision structures, an interactive
pattern editor, and a command-line animation generator.

The evolutionary search mutates a static structure, collides it with an incoming
pattern, and scores how well the structure recovers and produces a target pattern.
A complete example configuration is included.

## Quick start

**Requirements:** Java 11 or later. The graphical editor also requires a desktop
environment. No additional libraries or downloads are needed once Java is installed.

Extract this folder, open a terminal inside it, and start the evolutionary search:

```sh
java -jar GoL_evolutionary.jar
```

The search runs until it finds a successful candidate. There is no attempt limit;
press **Ctrl+C** to stop it. A successful result is not guaranteed.

## Pattern editor

Open an empty Kagome lattice:

```sh
java -cp GoL_evolutionary.jar GenericLifeGui Kagome
```

To load a pattern, append space-separated cell triples:

```sh
java -cp GoL_evolutionary.jar GenericLifeGui Kagome 0 0 A 0 0 B 1 0 C
```

Each cell is written as `x y subcell`, where `x` and `y` are integer lattice
coordinates and `subcell` is `A`, `B`, or `C`.

- **Click:** toggle a cell between alive and dead.
- **Drag:** paint live cells, visiting each cell once per drag.
- **Step:** advance one generation.
- **Text:** display the current pattern as cell triples for copying.
- **Clear:** clear the pattern.
- **Export...:** save the current view as SVG.

Choose an `.svg` filename for vector export. PDF selection writes an SVG beside
the requested PDF filename and reports that PDF output is unavailable. The
`.svgz` extension also writes ordinary, uncompressed SVG.

## Generate an animation

Supply an output filename followed by cell triples:

```sh
java -cp GoL_evolutionary.jar GenericLife Kagome example.gif 0 0 A 0 0 B 1 0 C
```

This simulates up to 300 generations, stopping on extinction or a repeated state.
GIFs loop indefinitely.

A separate random-pattern search is available:

```sh
java -cp GoL_evolutionary.jar GenericLife Kagome
```

It runs continuously and writes interesting animations to Java's temporary
folder. Press **Ctrl+C** to stop it.

## Configure the evolutionary search

Edit the constants near the top of `GenericLifeSymmetricEvolution.java`, then
rebuild the application using the instructions below.

| Setting | Purpose | Default |
| --- | --- | --- |
| `STATIC_PATTERN` | Starting structure to mutate | Included example |
| `INCOMING_PATTERN` | Incoming collision pattern | Included example |
| `DESIRED_PATTERN` | Target output pattern | Included example |
| `RADIUS` | Neighbour steps in each mutation's random walk | 4 |
| `MUTATIONS_PER_TRY` | Mutation operations per trial | 6 |
| `MAXGEN` | Maximum stored generations, including the initial state | 200 |
| `LOG_INTERVAL` | Attempts between progress reports | 2,000 |
| `ENFORCE_SYMMETRY` | Toggle reflected cells alongside selected cells | `true` |

Patterns are strings of space-separated cell triples. Search settings are compiled
into the application; they are not read from command-line arguments or external
configuration files.

Each trial starts from `STATIC_PATTERN`. Mutation anchors are selected from that
structure, and a random walk selects each cell to toggle. `REGION_ANCHORS` does
not affect mutation selection.

Reflection uses the fixed axis through `(-3, -3, A)` and `(-3, 7, A)`, implemented
in `Kagome.reflectExact`. Changing the symmetry-cell variables in `main` alone
does not change the reflection axis. Paired mutations preserve symmetry in a
symmetric starting structure; they do not make an asymmetric starting structure
fully symmetric.

Fitness combines the highest static recovery in the last ten stored generations
with the highest target-pattern coverage across the trial, then penalizes excess
final population. These two coverage peaks may occur in different generations.
The search uses a new random sequence on each launch.

## Search output

Files are written to the directory from which the application is launched.

| File | Contents |
| --- | --- |
| `fitness_log.txt` | Periodic progress and success details |
| `candidate_log.txt` | Scores and cell data for improved candidates |
| `candidate_<attempt>.gif` | Animation of an improved candidate |
| `reflector_success_<timestamp>.gif` | Animation of a successful trial |

Logs are appended across runs. Attempt numbers restart on each launch, so
candidate GIFs with matching names are overwritten. Use a separate working
folder for each run when keeping results from multiple searches.

## Build from source

The executable JAR is included, so compilation is only necessary after editing
the source. Building requires a **JDK 11 or later**, with `java`, `javac`, and
`jar` available on the command line.

On macOS or Linux:

```sh
sh build.sh
```

In Windows Command Prompt:

```bat
build.cmd
```

Both scripts compile the sources into `build/classes` and rebuild
`GoL_evolutionary.jar`. Run the updated application with:

```sh
java -jar GoL_evolutionary.jar
```

Alternatively, compile and run the sources directly:

```sh
javac *.java
java GenericLifeSymmetricEvolution
```

## Source guide

| File | Responsibility |
| --- | --- |
| `GenericLifeSymmetricEvolution.java` | Search configuration, mutation, simulation, fitness and candidate logging |
| `GenericLife.java` | B3/S23 simulation, raster rendering and command-line tools |
| `GifAnimation.java` | GIF encoding and frame timing |
| `GenericLifeGui.java` | Interactive editor and SVG export |
| `AbstractLattice.java` | Cell coordinates, polygon geometry, neighbours and text input/output |
| `Kagome.java` | Kagome geometry, oscillator filtering and reflection |
| `Tiling.java` | Common interface for lattice implementations |

Cells are neighbours when their polygons share a vertex. A dead cell becomes
alive with three live neighbours; a live cell survives with two or three.
The evolutionary simulator excludes a repeated generation, while the generic
simulator can include the closing frame of an oscillator.

## Credits

The generic simulation and editor were originally authored by Peter Taylor and
modified and extended by Henrik Schou Guttesen using ChatGPT 5.2. Attribution is
also included in the source files.
