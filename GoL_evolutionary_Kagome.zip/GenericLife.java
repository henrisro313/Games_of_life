import java.awt.Color;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.awt.image.ColorModel;
import java.awt.image.DataBuffer;
import java.awt.image.DataBufferByte;
import java.awt.image.IndexColorModel;
import java.awt.image.Raster;
import java.awt.image.WritableRaster;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Implements a Life-like cellular automaton on a generic grid.
 * Originally authored by Peter Taylor, modified and extended by Henrik Schou Guttesen using ChatGPT 5.2
 * See: http://codegolf.stackexchange.com/q/35827/194
 *
 * Usage:
 *   javac GenericLife.java AbstractLattice.java Tiling.java <tiling>.java
 *   java GenericLife <tiling> [<output.gif> <cell-data>]
 */
public class GenericLife {
    private static final Color GRID_COLOR = new Color(0x808080);
    private static final Color DEAD_COLOR = new Color(0xffffff);
    private static final Color LIVE_COLOR = new Color(0x00b092);

    private static final int MARGIN = 8;

    private static void usage() {
        System.out.println("Usage: java GenericLife <tiling> [<output.gif> <cell-data>]");
        System.out.println("For random search, supply just the tiling name");
        System.exit(1);
    }

    /** Runs the simulation for up to maxGen generations, including the initial state. */
    public static <Cell> List<Set<Cell>> evolvePublic(Tiling<Cell> tiling, Set<Cell> start, int maxGen) {
        return evolve(tiling, start, maxGen);
    }

    /** Writes an animation and reports failures to standard error. */
    public static <Cell> void createAnimatedGifPublic(
            String filename, Tiling<Cell> tiling, List<Set<Cell>> generations) {
        try {
            createAnimatedGif(filename, tiling, generations);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) throws Exception {
        if (args.length == 0 || args[0].equals("--help")) {
            usage();
        }

        Tiling<?> tiling = (Tiling<?>) Class.forName(args[0]).getDeclaredConstructor().newInstance();
        run(tiling, args);
    }

    private static <Cell> void run(Tiling<Cell> tiling, String[] args) throws IOException {
        if (args.length > 1) {
            String[] cellData = new String[args.length - 2];
            System.arraycopy(args, 2, cellData, 0, cellData.length);
            Set<Cell> alive;
            try {
                alive = tiling.parseCells(cellData);
            } catch (Exception ex) {
                usage();
                return;
            }

            createAnimatedGif(args[1], tiling, evolve(tiling, alive, 300));
        } else {
            search(tiling);
        }
    }

    private static <Cell> void search(Tiling<Cell> tiling) throws IOException {
        while (true) {
            // Build a starting generation within a certain radius of the initial cell.
            // This is a good place to tweak.
            Set<Cell> alive = new HashSet<>();
            double density = Math.random();
            Set<Cell> visited = new HashSet<>();
            Set<Cell> boundary = new HashSet<>();
            boundary.add(tiling.initialCell());
            for (int r = 0; r < 10; r++) {
                visited.addAll(boundary);
                Set<Cell> nextBoundary = new HashSet<>();
                for (Cell cell : boundary) {
                    if (Math.random() < density) {
                        alive.add(cell);
                    }
                    for (Cell neighbour : tiling.neighbours(cell)) {
                        if (!visited.contains(neighbour)) {
                            nextBoundary.add(neighbour);
                        }
                    }
                }

                boundary = nextBoundary;
            }

            final int maxGenerations = 100;
            List<Set<Cell>> generations = evolve(tiling, alive, maxGenerations);
            // Long-lived starting conditions might mean a glider, so are interesting.
            boolean interesting = generations.size() == maxGenerations;
            String description = "gens-" + maxGenerations;
            if (!interesting) {
                // We hit some oscillator - but was it an interesting one?
                int lastGen = generations.size() - 1;
                generations = evolve(tiling, generations.get(lastGen), generations.size());
                if (generations.size() > 1) {
                    int period = generations.size() - 1;
                    description = "oscillator-" + period;
                    interesting = tiling.isInterestingOscillationPeriod(period);
                    if (period > 10) {
                        System.out.println("Oscillator period " + period);
                    }
                } else {
                    String result = generations.get(0).isEmpty() ? "Extinction" : "Still life";
                    System.out.println(result + " at gen " + lastGen);
                }
            }

            if (interesting) {
                String filename = System.getProperty("java.io.tmpdir") + "/"
                        + tiling.getClass().getSimpleName() + "-" + System.nanoTime()
                        + "-" + description + ".gif";
                createAnimatedGif(filename, tiling, generations);
                System.out.println("Wrote " + generations.size() + " generations to " + filename);
            }
        }
    }

    /** Retains a repeated final generation for oscillators with periods greater than one. */
    public static <Cell> List<Set<Cell>> evolve(Tiling<Cell> tiling, Set<Cell> initial, int maxGenerations) {
        Map<Set<Cell>, Integer> firstSeen = new HashMap<>();
        List<Set<Cell>> generations = new ArrayList<>();
        generations.add(initial);
        firstSeen.put(initial, 0);

        Set<Cell> alive = initial;
        for (int gen = 1; gen < maxGenerations; gen++) {
            if (alive.size() == 0) {
                break;
            }

            Set<Cell> next = nextGeneration(tiling, alive);
            Integer previousGeneration = firstSeen.get(next);
            if (previousGeneration != null) {
                if (gen - previousGeneration > 1) { // Finish the loop.
                    generations.add(next);
                }
                break;
            }

            alive = next;
            generations.add(alive);
            firstSeen.put(alive, gen);
        }

        return generations;
    }

    private static <Cell> void createAnimatedGif(
            String filename, Tiling<Cell> tiling, List<Set<Cell>> generations) throws IOException {
        GifAnimation.write(filename, tiling, generations, MARGIN, 5, 500, false);
    }

    /** Applies B3/S23 using the tiling's vertex-sharing neighbourhood. */
    public static <Cell> Set<Cell> nextGeneration(Tiling<Cell> tiling, Set<Cell> gen) {
        Map<Cell, Integer> neighbourCount = new HashMap<>();
        for (Cell cell : gen) {
            for (Cell neighbour : tiling.neighbours(cell)) {
                Integer count = neighbourCount.get(neighbour);
                neighbourCount.put(neighbour, 1 + (count == null ? 0 : count.intValue()));
            }
        }

        Set<Cell> next = new HashSet<>();
        // Birth with three neighbours; survival with two or three.
        for (Map.Entry<Cell, Integer> e : neighbourCount.entrySet()) {
            if (e.getValue() == 3 || (e.getValue() == 2 && gen.contains(e.getKey()))) {
                next.add(e.getKey());
            }
        }

        return next;
    }

    public static <Cell> BufferedImage render(Tiling<Cell> tiling, Rectangle bounds, Collection<Cell> alive) {
        // Create a suitable paletted image
        int width = bounds.width;
        int height = bounds.height;
        byte[] data = new byte[width * height];
        int[] palette = {GRID_COLOR.getRGB(), DEAD_COLOR.getRGB(), LIVE_COLOR.getRGB()};
        ColorModel colourModel = new IndexColorModel(8, palette.length, palette, 0, false, -1, DataBuffer.TYPE_BYTE);
        DataBufferByte buffer = new DataBufferByte(data, width * height);
        WritableRaster raster = Raster.createPackedRaster(
                buffer, width, height, width, new int[] {0xff}, new Point(0, 0));
        BufferedImage image = new BufferedImage(colourModel, raster, true, null);
        Graphics g = image.createGraphics();

        try {
            // Render the tiling.
            // We assume that either one of the live cells or the "initial cell" is in bounds.
            Set<Cell> visited = new HashSet<>();
            Set<Cell> unvisited = new HashSet<>(alive);
            unvisited.add(tiling.initialCell());
            while (!unvisited.isEmpty()) {
                Iterator<Cell> it = unvisited.iterator();
                Cell current = it.next();
                it.remove();
                visited.add(current);

                Rectangle cellBounds = new Rectangle(-1, -1);
                int[][] cellVertices = tiling.bounds(current);
                int[] xs = cellVertices[0], ys = cellVertices[1];
                for (int i = 0; i < xs.length; i++) {
                    cellBounds.add(xs[i], ys[i]);
                    xs[i] -= bounds.x;
                    ys[i] -= bounds.y;
                }

                if (!bounds.intersects(cellBounds)) {
                    continue;
                }

                g.setColor(alive.contains(current) ? LIVE_COLOR : DEAD_COLOR);
                g.fillPolygon(xs, ys, xs.length);
                g.setColor(GRID_COLOR);
                g.drawPolygon(xs, ys, xs.length);

                for (Cell neighbour : tiling.neighbours(current)) {
                    if (!visited.contains(neighbour)) {
                        unvisited.add(neighbour);
                    }
                }
            }

        } finally {
            g.dispose();
        }
        return image;
    }
}
